Store code of window server source files
