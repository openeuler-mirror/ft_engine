# window_manager 

#### 介绍
window_manager目录是 ft engine 的窗口管理部分。

本模块基于OpenHarmony-3.2-Release。将在openEuler做适配，同时抽象出FT协议的基本接口。
