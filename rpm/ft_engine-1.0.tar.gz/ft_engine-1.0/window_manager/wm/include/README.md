Store code of window client inner header files
