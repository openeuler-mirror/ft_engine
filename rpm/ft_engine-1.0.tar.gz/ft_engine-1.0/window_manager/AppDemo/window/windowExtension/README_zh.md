# immersive

### 简介

本示例适用于介绍如何使用AbilityComponent，以及通过abilityComponent启动WindowExtension。

### 使用说明

启动AbilityComponent应用，此应用窗口内部展示WindowExension中的内容。

### 约束与限制

本示例仅支持在标准系统上运行，AbilityComponent中需要配置WindowExtension应用的bundleName和AbilityName。

